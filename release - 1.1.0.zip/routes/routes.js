/*jshint esversion: 6*/
module.exports = function (app) {
	app.get('/', function (req, res) {
		res.send('Howdy');
	});
};