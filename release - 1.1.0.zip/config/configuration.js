module.exports = {    
    'passport_secret': 'lemongrass',
    'db_url': 'mongodb://henry:98CCfr58@ds227858.mlab.com:27858/tracker-app'
};